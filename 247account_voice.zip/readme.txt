English:
Hello Everyone To Day I made a streaming + voice for discord account free without offline 24/7 and you can change your activity and add your voice channel.
Tortaul:
1- Add Your Discord Token In Secerts Type (token)
2- Add Your Voice Id Channel In index.js : https://media.discordapp.net/attachments/1106236290455851109/1106901203113213952/Screenshot_20230513_140926.jpg
3- You Can Change Your Activity In index.js : https://media.discordapp.net/attachments/1106236290455851109/1106901249959399484/Screenshot_20230513_140853.jpg
4- Now You Can Run The Repl And Join Our Server https://discord.gg/EKKNt3QXaT

